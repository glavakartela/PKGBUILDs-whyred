project(
    'q6voiced',
    'c',
    license_files: './LICENSE',
    license: 'MIT',
    meson_version: '>=1.10.0',
    version: '0.2.1',
)

pkg = import('pkgconfig')
dbus = dependency('dbus-1')
alsa = dependency('alsa')

executable('q6voiced', 'q6voiced.c', dependencies: [dbus, alsa], install: true)

if get_option('openrc').enabled()
    configure_file(
        input: 'q6voiced.initd.in',
        output: 'q6voiced',
        configuration: {
            'bindir': get_option('prefix') / get_option('bindir'),
            'datadir': get_option('prefix') / get_option('datadir'),
        },
        build_subdir: 'services',
        install: true,
        install_mode: 'rwxr-xr-x',
        install_dir: get_option('sysconfdir') / 'init.d',
    )
endif

if get_option('systemd').enabled()
    configure_file(
        input: 'q6voiced.service.in',
        output: 'q6voiced.service',
        configuration: {
            'bindir': get_option('prefix') / get_option('bindir'),
            'datadir': get_option('prefix') / get_option('datadir'),
        },
        build_subdir: 'services',
        install: true,
        install_dir: get_option('prefix') / 'lib' / 'systemd' / 'system',
    )
endif
