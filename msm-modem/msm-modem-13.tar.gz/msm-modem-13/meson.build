project('msm-modem', 'c',
  license: 'GPL-3.0-or-later',
  meson_version: '>=1.1',
  version: '13',
)

openrcinitdir = get_option('sysconfdir') / 'init.d'
openrcconfdir = get_option('sysconfdir') / 'conf.d'
systemdsystemdir = get_option('prefix') / 'lib' / 'systemd' / 'system'
udevdir = get_option('prefix') / 'lib' / 'udev' / 'rules.d'

openrcinits = []
systemdsystemunits = []

if get_option('uim-selection')
  install_data('msm-modem-uim-selection',
    install_mode : 'rwxr-xr-x',
    install_dir: get_option('prefix') / get_option('libexecdir'),
  )

  openrcinits += 'msm-modem-uim-selection'
  if get_option('openrc')
    install_data('msm-modem-uim-selection.confd',
      install_dir: openrcconfdir,
      rename: 'msm-modem-uim-selection',
    )
  endif

  systemdsystemunits += 'msm-modem-uim-selection.service'
  if get_option('systemd')
    install_data('msm-modem-uim-selection-rmtfs.override.conf',
      install_dir: systemdsystemdir / 'rmtfs.service.d',
      rename: 'msm-modem-uim-selection.override.conf',
    ) 
  endif
endif

if get_option('wwan-port')
  install_data('msm-modem-wwan-port',
    install_mode : 'rwxr-xr-x',
    install_dir: get_option('prefix') / get_option('libexecdir'),
  )
  openrcinits += 'msm-modem-wwan-port'
  systemdsystemunits += 'msm-modem-wwan-port.service'
endif

if get_option('downstream') and get_option('openrc')
  executable('keepfileopen',
    'keepfileopen.c',
    install: true,
    install_dir: get_option('prefix') / get_option('libexecdir'),
  )

  openrcinits += 'msm-modem-downstream'

  install_data('msm-modem-downstream.rules',
    install_dir: udevdir,
    rename: '55-msm-modem-downstream.rules',
  )
endif

if get_option('openrc')
  foreach i : openrcinits
    configure_file(
      input: i + '.initd.in',
      output: i,
      configuration: { 'libexecdir': get_option('prefix') / get_option('libexecdir') },
      install: true,
      install_mode : 'rwxr-xr-x',
      install_dir: openrcinitdir,
    )
  endforeach
endif

if get_option('systemd')
  foreach i : systemdsystemunits
    configure_file(
      input: i + '.in',
      output: i,
      configuration: { 'libexecdir': get_option('prefix') / get_option('libexecdir') },
      install: true,
      install_dir: systemdsystemdir,
    )
  endforeach
endif
