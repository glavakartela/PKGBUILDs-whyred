# Release instructions

1. Bump version in `meson.build`.
2. Update [CHANGELOG.md](./CHANGELOG.md).
3. Tag new release with `git tag -s -m "bootmax X.Y.Z" vX.Y.Z`
