# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.1] - 2026-02-07

### Added
- Bootmac systemd units can be installed even if not linked against systemd.

### Fixed
- Also use unit activation for wifi under systemd

## [0.7.0] - 2025-08-15

### Fixed
- Bootmac under systemd is more stable.

### Added
- Release instructions.

## [0.6.0] - 2025-01-23

### Added
- Systemd support.

## [0.5.0] - 2024-01-23

### Added
- Add parameter for variable prefix.
- Add parameters for interface names.

### Fixed
- Try to down `hci0` before accessing it.

## [0.4.0] - 2024-01-13

### Added
- Generate-only mode.

## [0.3.0] - 2023-12-27

### Changed
- Split WLAN and Bluetooth into separate configurations.

## [0.2.1] - 2023-09-22

### Fixed
- Workaround hang in `btmgmt`.

## [0.2.0] - 2022-08-16

### Fixed
- Honor rfkill state.
- Use local administered address.

### Added
- Add shellcheck CI.

## [0.1.0] - 2022-08-15

Initial version.

<!-- links to diffs between releases -->
[0.1.0]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/fff61513aebc5901292fbb09533cbcfeb0ae6daa...v0.1.0
[0.2.0]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/v0.1.0...v0.2.0
[0.2.1]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/v0.2.0...v0.2.1
[0.3.0]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/v0.2.1...v0.3.0
[0.4.0]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/v0.3.0...v0.4.0
[0.5.0]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/v0.4.0...v0.5.0
[0.6.0]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/v0.5.0...v0.6.0
[0.7.0]: https://gitlab.postmarketos.org/postmarketOS/bootmac/-/compare/v0.6.0...v0.7.0
