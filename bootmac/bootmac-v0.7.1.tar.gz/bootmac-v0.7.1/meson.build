project(
    'bootmac', 'c',
    version: '0.7.1',
    license : 'GPL-3.0-or-later',
)

prefix = get_option('prefix')
bindir = prefix / get_option('bindir')
libdir = prefix / get_option('libdir')

pkg = import('pkgconfig')

systemd = dependency('systemd', required : false)
systemd_units_opt = get_option('systemd_units')
systemd_system_unit_dir = prefix / 'lib' / 'systemd' / 'system'
install_systemd = systemd.found() or systemd_units_opt

# udev is only used to get the rules location, we can have a fallback
udev = dependency('udev', required : false)
if udev.found()
    udev_rules_dir = udev.get_variable(pkgconfig : 'udevdir') / 'rules.d'
else
    udev_rules_dir = libdir / 'udev' / 'rules.d'
endif

bt_udev_rules = 'bootmac-bluetooth.rules'
wifi_udev_rules = 'bootmac-wifi.rules'

if systemd.found()
    systemd_system_unit_dir = systemd.get_variable(
        pkgconfig : 'systemdsystemunitdir',
        pkgconfig_define: ['prefix', prefix]
    )
endif

install_data(
    bt_udev_rules,
    wifi_udev_rules,
    install_dir: udev_rules_dir,
    rename: [
        '90-bootmac-bluetooth.rules',
        '90-bootmac-wifi.rules'
    ],
)

if install_systemd
    install_data(
        'systemd/bootmac@.service',
        install_dir: systemd_system_unit_dir
    )
endif

install_data(
    'bootmac',
    install_dir: bindir,
    install_mode: 'rwxr-xr-x'
)
